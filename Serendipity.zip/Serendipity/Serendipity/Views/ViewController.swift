//
//  ViewController.swift
//  Serendipity
//
//  Created by Kevin Pradjinata on 1/30/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

